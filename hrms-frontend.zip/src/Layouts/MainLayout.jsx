import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  Box,
  ClickAwayListener,
  InputBase,
  Paper,
  Typography,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import { Outlet, useNavigate } from "react-router-dom";
import Navbar from "../Components/Navbar/Navbar";
import { getStoredAuthUser, logoutFromServer } from "../API/auth";
import LocationConsentDialog from "../Components/LocationConsentDialog";
import NotificationConsentDialog from "../Components/NotificationConsentDialog";
import { shouldPromptLocationConsent } from "../Utils/LocationConsent";
import NotificationProvider from "../Contexts/NotificationProvider";
import NotificationBell from "../Components/Notifications/NotificationBell";
import NotificationRouteReadTracker from "../Components/Notifications/NotificationRouteReadTracker";

function MainLayout() {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [authUser, setAuthUser] = useState(getStoredAuthUser());
  const [locationConsentResolved, setLocationConsentResolved] = (
    useState(() => !shouldPromptLocationConsent())
  );
  const menuRef = useRef(null);

  useEffect(() => {
    const handleStorage = () => {
      setAuthUser(getStoredAuthUser());
    };

    window.addEventListener("storage", handleStorage);

    return () => {
      window.removeEventListener("storage", handleStorage);
    };
  }, []);

  const employeeName = useMemo(() => {
    const employeeDisplayName = authUser?.employee?.display_name;
    const userDisplayName = authUser?.display_name;
    const userLogin = authUser?.user_login;

    return employeeDisplayName || userDisplayName || userLogin || "帳戶";
  }, [authUser]);

  const employeeId = useMemo(
    () => Number(authUser?.employee?.employee_id || 0),
    [authUser],
  );

  const handleLocationConsentResolved = useCallback(() => {
    setLocationConsentResolved(true);
  }, []);

  async function handleLogout() {
    try {
      await logoutFromServer();
    } finally {
      setMenuOpen(false);
      navigate("/login", { replace: true });
    }
  }

  return (
    <NotificationProvider
      key={employeeId || "no-employee"}
      employeeId={employeeId}
    >
      <NotificationRouteReadTracker />

      <Box sx={{ minHeight: "100vh", bgcolor: "#f3f4f6" }}>
      <LocationConsentDialog
        onResolved={handleLocationConsentResolved}
      />
      <NotificationConsentDialog
        enabled={locationConsentResolved}
        employeeId={employeeId}
      />
      <Box
        sx={{
          display: { xs: "none", md: "block" },
          height: "60px",
          bgcolor: "#ffffff",
          borderBottom: "1px solid #e5e7eb",
        }}
      >
        <Box
          sx={{
            width: "100%",
            maxWidth: "1180px",
            mx: "auto",
            px: { xs: "16px", md: "24px" },
            height: "60px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Box
            sx={{
              fontSize: { xs: "24px", md: "30px" },
              fontWeight: 700,
              color: "#1b9ad7",
              lineHeight: 1,
              display: "flex",
              alignItems: "flex-start",
              gap: "4px",
              flexShrink: 0,
            }}
          >
            <Box component="span">SEHO</Box>
            <Box
              component="span"
              sx={{
                fontSize: "12px",
                border: "1px solid #67b7e5",
                borderRadius: "4px",
                px: "4px",
                py: "1px",
                mt: "2px",
                color: "#67b7e5",
              }}
            >
              HR
            </Box>
          </Box>

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: { xs: "12px", md: "20px" },
              minWidth: 0,
            }}
          >
            <Box
              sx={{
                width: { xs: "180px", md: "260px" },
                height: "34px",
                border: "1px solid #d1d5db",
                borderRadius: "18px",
                display: { xs: "none", sm: "flex" },
                alignItems: "center",
                px: "12px",
                bgcolor: "#ffffff",
              }}
            >
              <SearchIcon
                sx={{ fontSize: "18px", color: "#9ca3af", mr: "6px" }}
              />
              <InputBase
                placeholder="人員搜尋"
                sx={{
                  flex: 1,
                  fontSize: "14px",
                  color: "#374151",
                }}
              />
            </Box>

            <NotificationBell />

            <ClickAwayListener onClickAway={() => setMenuOpen(false)}>
              <Box
                ref={menuRef}
                sx={{
                  position: "relative",
                  display: "flex",
                  alignItems: "center",
                  flexShrink: 0,
                }}
              >
                <Box
                  onClick={() => setMenuOpen((prev) => !prev)}
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: "6px",
                    flexShrink: 0,
                    cursor: "pointer",
                    userSelect: "none",
                    px: "6px",
                    py: "4px",
                    borderRadius: "8px",
                    "&:hover": {
                      bgcolor: "#f3f4f6",
                    },
                  }}
                >
                  <AccountCircleIcon
                    sx={{ color: "#8b8b8b", fontSize: "28px" }}
                  />
                  <Typography
                    sx={{
                      fontSize: { xs: "13px", md: "15px" },
                      color: "#6b7280",
                      whiteSpace: "nowrap",
                      maxWidth: "180px",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {employeeName}
                  </Typography>
                  <KeyboardArrowDownIcon
                    sx={{
                      color: "#9ca3af",
                      fontSize: "18px",
                      transform: menuOpen ? "rotate(180deg)" : "rotate(0deg)",
                      transition: "transform 0.2s ease",
                    }}
                  />
                </Box>

                {menuOpen ? (
                  <Paper
                    elevation={4}
                    sx={{
                      position: "absolute",
                      top: "calc(100% + 8px)",
                      right: 0,
                      minWidth: "140px",
                      py: "6px",
                      borderRadius: "12px",
                      overflow: "hidden",
                      zIndex: 20,
                    }}
                  >
                    <Box
                      onClick={handleLogout}
                      sx={{
                        px: "14px",
                        py: "10px",
                        fontSize: "14px",
                        color: "#374151",
                        cursor: "pointer",
                        "&:hover": {
                          bgcolor: "#f9fafb",
                        },
                      }}
                    >
                      登出
                    </Box>
                  </Paper>
                ) : null}
              </Box>
            </ClickAwayListener>
          </Box>
        </Box>
      </Box>

      <Navbar />

      <Box
        sx={{
          width: "100%",
          maxWidth: "1180px",
          mx: "auto",
          px: { xs: "16px", md: "24px" },
          py: "20px",
        }}
      >
        <Outlet />
      </Box>
      </Box>
    </NotificationProvider>
  );
}

export default MainLayout;
