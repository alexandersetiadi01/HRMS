import { Box, Typography } from "@mui/material";

function UnreadDot() {
  return (
    <Box
      component="span"
      aria-label="未讀公告"
      sx={{
        width: "8px",
        height: "8px",
        borderRadius: "50%",
        bgcolor: "#ef4444",
        flexShrink: 0,
      }}
    />
  );
}

export function DesktopTable({
  rows = [],
  onOpenItem,
  isSourceUnread,
  highlightedId = 0,
}) {
  return (
    <Box>
      <Box
        sx={{
          border: "1px solid #d3d3d3",
          bgcolor: "#ffffff",
        }}
      >
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "1fr 28% 32%",
            minHeight: "38px",
            alignItems: "center",
            px: "8px",
            background: (
              "linear-gradient("
              + "to bottom, #f7f7f7, #dddddd)"
            ),
            borderBottom: "1px solid #d3d3d3",
          }}
        >
          <Typography
            sx={{
              fontSize: "15px",
              fontWeight: 700,
              color: "#333333",
            }}
          >
            標題
          </Typography>

          <Typography
            sx={{
              fontSize: "15px",
              fontWeight: 700,
              color: "#333333",
            }}
          >
            發佈者
          </Typography>

          <Typography
            sx={{
              fontSize: "15px",
              fontWeight: 700,
              color: "#333333",
            }}
          >
            發佈時間
          </Typography>
        </Box>

        {rows.length === 0 ? (
          <Box
            sx={{
              minHeight: "38px",
              px: "8px",
              display: "flex",
              alignItems: "center",
            }}
          >
            <Typography
              sx={{
                fontSize: "15px",
                color: "#6b7280",
              }}
            >
              目前沒有部門公告。
            </Typography>
          </Box>
        ) : (
          rows.map((item) => {
            const isHighlighted = (
              Number(item.id)
              === Number(highlightedId)
            );

            return (
              <Box
                key={item.id}
                onClick={() => onOpenItem(item)}
                sx={{
                  display: "grid",
                  gridTemplateColumns: "1fr 28% 32%",
                  minHeight: "38px",
                  alignItems: "center",
                  px: "8px",
                  cursor: "pointer",
                  borderBottom: "1px solid #d3d3d3",
                  bgcolor: isHighlighted
                    ? "#fff7cc"
                    : "transparent",
                  "&:hover": {
                    bgcolor: isHighlighted
                      ? "#fff1a8"
                      : "#fafafa",
                  },
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    gap: "8px",
                    minWidth: 0,
                  }}
                >
                  {isSourceUnread?.(item.id) ? (
                    <UnreadDot />
                  ) : null}

                  <Typography
                    sx={{
                      minWidth: 0,
                      fontSize: "15px",
                      color: "#1f2f4a",
                      whiteSpace: "nowrap",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                    }}
                  >
                    {item.title}
                  </Typography>
                </Box>

                <Typography
                  sx={{
                    fontSize: "15px",
                    color: "#1f2f4a",
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                  }}
                >
                  {item.publisher}
                </Typography>

                <Typography
                  sx={{
                    fontSize: "15px",
                    color: "#1f2f4a",
                    whiteSpace: "nowrap",
                  }}
                >
                  {item.publishTime}
                </Typography>
              </Box>
            );
          })
        )}
      </Box>
    </Box>
  );
}

export function MobileList({
  rows = [],
  onOpenItem,
  isSourceUnread,
  highlightedId = 0,
}) {
  return (
    <Box
      sx={{
        border: "1px solid #d3d3d3",
        bgcolor: "#ffffff",
        overflow: "hidden",
      }}
    >
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: "1.4fr 1fr 1fr",
          minHeight: "38px",
          alignItems: "center",
          px: "8px",
          background: (
            "linear-gradient("
            + "to bottom, #f7f7f7, #dddddd)"
          ),
          borderBottom: "1px solid #d3d3d3",
        }}
      >
        <Typography
          sx={{
            fontSize: "14px",
            fontWeight: 700,
            color: "#333333",
            pr: "8px",
          }}
        >
          標題
        </Typography>

        <Typography
          sx={{
            fontSize: "14px",
            fontWeight: 700,
            color: "#333333",
            pr: "8px",
          }}
        >
          發佈者
        </Typography>

        <Typography
          sx={{
            fontSize: "14px",
            fontWeight: 700,
            color: "#333333",
          }}
        >
          發佈時間
        </Typography>
      </Box>

      {rows.length === 0 ? (
        <Box
          sx={{
            px: "8px",
            py: "10px",
          }}
        >
          <Typography
            sx={{
              fontSize: "14px",
              color: "#6b7280",
            }}
          >
            目前沒有部門公告。
          </Typography>
        </Box>
      ) : (
        rows.map((item) => {
          const isHighlighted = (
            Number(item.id)
            === Number(highlightedId)
          );

          return (
            <Box
              key={item.id}
              onClick={() => onOpenItem(item)}
              sx={{
                display: "grid",
                gridTemplateColumns: "1.4fr 1fr 1fr",
                alignItems: "start",
                px: "8px",
                py: "10px",
                cursor: "pointer",
                borderBottom: "1px solid #d3d3d3",
                bgcolor: isHighlighted
                  ? "#fff7cc"
                  : "transparent",
                "&:last-of-type": {
                  borderBottom: "none",
                },
                "&:hover": {
                  bgcolor: isHighlighted
                    ? "#fff1a8"
                    : "#fafafa",
                },
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  alignItems: "flex-start",
                  gap: "6px",
                  pr: "8px",
                }}
              >
                {isSourceUnread?.(item.id) ? (
                  <UnreadDot />
                ) : null}

                <Typography
                  sx={{
                    fontSize: "14px",
                    color: "#1f2f4a",
                    fontWeight: 700,
                    lineHeight: 1.5,
                    wordBreak: "break-word",
                  }}
                >
                  {item.title}
                </Typography>
              </Box>

              <Typography
                sx={{
                  fontSize: "14px",
                  color: "#1f2f4a",
                  pr: "8px",
                  lineHeight: 1.5,
                  wordBreak: "break-word",
                  overflowWrap: "anywhere",
                }}
              >
                {item.publisher}
              </Typography>

              <Typography
                sx={{
                  fontSize: "14px",
                  color: "#1f2f4a",
                  lineHeight: 1.5,
                  wordBreak: "break-word",
                  overflowWrap: "anywhere",
                }}
              >
                {item.publishTime}
              </Typography>
            </Box>
          );
        })
      )}
    </Box>
  );
}